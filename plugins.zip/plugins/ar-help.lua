do 

function run(msg, matches) 
  return [[ 
         🔱 مرحبا بكم في بوت الملك 🔱   
             🏆ــــــــــــــــــــــــــــــ🏆
         🇮🇶🇮🇶🇮🇶🇮🇶🇮🇶🇮🇶🇮🇶
🍁 م1 ↜↯
    ((لُْعـرَضُ اوَامٌرَ ادِارَُه الُمٌجْمٌوَْعات))
ْ
🍁 م2 ↜ ↯
   ((لُْعـرَضُ اوَامٌرَ الُحُمٌايَُه الُمٌجْمٌوَْعاتْ))

🍁 م المطور ↜ ↯
        ((لُْعـرَضُ اوَامٌرَ الُمٌطِوَرَ  ))  
  
             🏆ــــــــــــــــــــــــــــــ🏆
🔱DEV1: @illOlli
🔱DEV2: @Sadikal_knani10 
🔱channal: @kingtele1
]] 

end 

return { 
description = "Help list", 
usage = "Help list", 
patterns = { 
"^(الاوامر)$", 
}, 
run = run 
} 
end
