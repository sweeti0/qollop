do

function run(msg, matches)
return [[

🔸 يعمل البوت ع مجموعات السوبر تصل الى 5k 🌐

    🔸تم تطوير البوت وصنعه بواسطة 🔸
                   🔸  صاد و بكر🔸
                      
                      -🔧 DEV 👹: @sadikal_knani10 - @illOlli 
                      
             🔸    تابع كل ما يخص البوتات ع قناة البوت 👇🔸
                      
                    -🔧 channel 👹: kingtele1

]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(dev)$",
},
run = run 
}
end
